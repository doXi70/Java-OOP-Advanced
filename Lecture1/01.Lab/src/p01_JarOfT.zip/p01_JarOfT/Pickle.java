package p01_JarOfT;

public class Pickle {
    private String name;
    private int age;

    public Pickle() {
    }

    public Pickle(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }
}
