package p03_CoffeeMachine;

public enum CoffeeType {
    ESPRESSO, LATTE, IRISH;
}
