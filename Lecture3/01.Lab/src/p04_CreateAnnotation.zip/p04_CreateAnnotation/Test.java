package p04_CreateAnnotation;

@Subject(categories = {"Test", "Annotation"})
public class Test {

}
