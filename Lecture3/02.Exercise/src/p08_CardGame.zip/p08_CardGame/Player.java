package p08_CardGame;

import p08_CardGame.card_comparator.ByPower;
import p08_CardGame.exceptions.CardDoesNotExistsException;
import p08_CardGame.exceptions.CardNotInDeckException;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class Player {
    private static final int MAX_CARDS_IN_HAND = 5;
    private final DeckOfCards deck = new DeckOfCards();
    private String name;
    private Set<Card> hand;

    public Player(String name) {
        this.name = name;
        this.deck.buildStandardDeck();
        this.hand = new TreeSet<>(new ByPower());
    }

    private boolean cardExistsInHand(Card cardToAdd) {
        for (Card card : hand) {
            if (card.getRank() == cardToAdd.getRank() &&
                    card.getSuite() == cardToAdd.getSuite()) {
                throw new CardNotInDeckException();
            }
        }

        return false;
    }

    private boolean cardIsInTheDeck(Card cardToCheck) {
        for (Card card : deck.getCards()) {
            if (card.getSuite() == cardToCheck.getSuite() &&
                    card.getRank() == cardToCheck.getRank()) {
                return true;
            }
        }

        throw new CardDoesNotExistsException();
    }

    public void addCard(Card card) {
        if (!cardExistsInHand(card) && cardIsInTheDeck(card)) {
            this.hand.add(card);
        }
    }

    public int getHandSize() {
        return this.hand.size();
    }

    public Card getBestCard() {
        return new ArrayList<>(this.hand).get(4);
    }

    @Override
    public String toString() {
        return String.format("%s wins with %s.",
                this.name, this.getBestCard());
    }
}
