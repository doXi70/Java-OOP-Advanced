package p01_CardSuit;

public enum CardSuite {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
