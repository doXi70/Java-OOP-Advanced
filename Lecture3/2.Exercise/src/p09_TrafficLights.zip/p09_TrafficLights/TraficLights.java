package p09_TrafficLights;

public enum TraficLights {
    GREEN, YELLOW, RED;
}
